"""
build_prompts.py - Builds prompts in the AI Vault master template and writes prompts_batch.csv.

HOW TO ADD A NEW PROMPT
  1. Copy any SPEC block at the bottom (the dict inside SPECS).
  2. Change category, title, opening, task, intake, report, sections, extras, closing.
  3. Run:  python build_prompts.py
  4. Import: python import_prompts.py prompts_batch.csv --replace

The template (identical for every prompt):
  Opening (Act as...) -> Task -> Intake questions -> 12 numbered report sections
  -> Presentation line + closing line.
"""
import csv
import os

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
OUT_PATH = os.path.join(BASE_DIR, "prompts_batch.csv")


def S(title, intro, items=""):
    """One report section. items is a ';'-separated string (leave empty for no list)."""
    return (title, intro, [x.strip() for x in items.split(";") if x.strip()])


def join_items(items):
    if len(items) == 1:
        return items[0]
    return "; ".join(items[:-1]) + "; and " + items[-1]


def render(spec):
    lines = [spec["opening"], "", spec["task"], ""]
    lines.append(
        f"Begin by asking detailed questions about {spec['intake_about']}: {join_items(spec['intake'])}."
    )
    lines.append("")
    lines.append(f"Once you have {spec['context']}, create a thorough {spec['report']} that includes:")
    lines.append("")
    for n, (title, intro, items) in enumerate(spec["sections"], 1):
        if items:
            lines.append(f"{n}. **{title}** \u2013 {intro}: {join_items(items)}.")
        else:
            lines.append(f"{n}. **{title}** \u2013 {intro}")
        lines.append("")
    lines.append(
        f"Present the report with clear sections, actionable recommendations, and {spec['extras']}. {spec['closing']}"
    )
    return "\n".join(lines).strip()


SPECS = [
    # ------------------------------------------------------------------ 1
    dict(
        category="Coding",
        title="Senior Code Review Expert",
        opening="Act as a Senior Software Engineer and Code Review Expert with 15+ years of experience reviewing code across multiple languages and frameworks. You have conducted over 5,000 code reviews for companies ranging from startups to tech giants like Google, Microsoft, and Amazon. Your expertise includes code quality, performance optimization, security vulnerabilities, design patterns, clean code principles, and architectural best practices.",
        task="Your task is to review my code snippet, project, or pull request and provide a comprehensive analysis with actionable improvements.",
        intake_about="the code",
        intake=["programming language and framework", "purpose and functionality of the code", "performance requirements", "security considerations", "team coding standards", "any specific concerns or areas of focus"],
        context="the code context",
        report="Code Review Report",
        sections=[
            S("Code Quality Analysis", "A comprehensive review of code quality", "readability and clarity; naming conventions and consistency; code organization and structure; adherence to SOLID principles; DRY (Don't Repeat Yourself) compliance; overall maintainability score"),
            S("Performance Optimization", "Identify performance bottlenecks", "time complexity analysis; memory usage optimization; database query optimization; inefficient loops and algorithms; caching opportunities; performance improvement recommendations with code examples"),
            S("Security Vulnerability Assessment", "Identify security issues", "input validation and sanitization; SQL injection and XSS vulnerabilities; authentication and authorization checks; secure data storage and transmission; dependency vulnerabilities; security best practices with fixes"),
            S("Error Handling & Edge Cases", "Review error handling", "exception handling strategy; edge case coverage; graceful degradation; logging and debugging support; user-friendly error messages"),
            S("Design Patterns & Architecture", "Evaluate architectural decisions", "appropriate use of design patterns; separation of concerns; dependency injection and inversion of control; modularity and extensibility; architectural improvement recommendations"),
            S("Test Coverage & Quality", "Assess testing", "unit test coverage and quality; integration and end-to-end tests; test readability and maintainability; edge case testing; test automation recommendations"),
            S("Documentation & Comments", "Review documentation", "code comments quality and usefulness; function and class documentation; README and setup instructions; API documentation; documentation improvement suggestions"),
            S("Refactoring Recommendations", "Specific refactoring suggestions", "code smells and how to fix them; duplicate code elimination; simplifying complex logic; extracting reusable components; before/after code examples"),
            S("Dependency Management", "Review dependencies", "unnecessary dependencies; outdated packages and security vulnerabilities; version management strategy; dependency size and performance impact; dependency optimization recommendations"),
            S("Language-Specific Best Practices", "Best practices for your specific language", "language-specific patterns and idioms; framework-specific recommendations; style guide compliance; common pitfalls to avoid"),
            S("Improved Code Version", "Provide a refactored version of the code with all improvements applied."),
            S("Implementation Roadmap", "A step-by-step plan to implement the improvements", "priority order of fixes; estimated effort and complexity; testing strategy for changes; rollout recommendations"),
        ],
        extras="code examples",
        closing="End with the three most critical improvements to make immediately and a summary of expected benefits.",
    ),
    # ------------------------------------------------------------------ 2
    dict(
        category="Marketing",
        title="Full-Funnel Campaign Strategist",
        opening="Act as a Senior Growth Marketing Strategist and Campaign Architect with 15+ years of experience launching high-performing campaigns across paid, owned, and earned channels. You have led campaigns for over 300 brands, from early-stage startups to global companies like Nike, Shopify, and HubSpot. Your expertise includes funnel strategy, paid media, content marketing, email automation, conversion rate optimization, and marketing analytics.",
        task="Your task is to design a complete full-funnel marketing campaign for my product or business that turns strangers into loyal customers.",
        intake_about="my business",
        intake=["product or service and its price", "target audience and their biggest pains", "monthly marketing budget", "primary goal and timeline", "current channels and results so far", "main competitors and brand voice"],
        context="the business context",
        report="Campaign Strategy Report",
        sections=[
            S("Audience & Customer Profile", "Define who we are speaking to", "ideal customer profile; core pains and desired outcomes; buying triggers and objections; the exact language customers use; where they spend time online"),
            S("Positioning & Messaging", "Craft a message that stands out", "unique value proposition; key messaging pillars; competitor differentiation; proof points and social proof; brand voice guidelines"),
            S("Awareness Stage", "Attract attention at the top of the funnel", "best channels for reach; content formats and hooks; influencer and partnership ideas; organic versus paid mix; sample post and ad concepts"),
            S("Consideration Stage", "Build trust and educate prospects", "lead magnets and free resources; email nurture sequence outline; case studies and testimonials; comparison and FAQ content; retargeting strategy"),
            S("Conversion Stage", "Turn interest into sales", "offer structure and pricing psychology; landing page headline and layout; call-to-action variations; urgency and scarcity tactics that stay honest; checkout and follow-up improvements"),
            S("Retention & Loyalty", "Keep customers coming back", "onboarding sequence; upsell and cross-sell opportunities; referral and loyalty programs; win-back campaigns; customer feedback loops"),
            S("Channel Strategy & Budget Allocation", "Spend the budget where it works", "channel-by-channel role and priority; recommended budget split; expected cost ranges; tools and software stack; scaling rules for winning channels"),
            S("Content Calendar", "Plan the first month of execution", "weekly themes; content types and formats; posting frequency; repurposing workflow; ownership and approval steps"),
            S("Ad Copy & Creative Assets", "Provide ready-to-use creative", "five ad headlines; three primary text variations; email subject lines; landing page hero copy; creative briefs for designers or video editors"),
            S("Metrics & Benchmarks", "Define how success is measured", "KPIs for each funnel stage; realistic benchmark ranges; attribution approach; dashboard setup; warning signs of underperformance"),
            S("Testing Roadmap", "Plan structured experiments", "hypotheses to test first; A/B test design; sample sizes and timelines; how to read results; how to roll out winners"),
            S("90-Day Action Plan", "A step-by-step execution schedule", "week-by-week milestones; priority order of tasks; team roles and resources; budget checkpoints; scaling and optimization plan"),
        ],
        extras="ready-to-use copy examples",
        closing="End with the three highest-impact actions to take in the first week and a summary of expected results.",
    ),
    # ------------------------------------------------------------------ 3
    dict(
        category="Business",
        title="Startup Strategy Advisor",
        opening="Act as a Startup Advisor and Business Strategist with 15+ years of experience as a founder, operator, and investor. You have advised over 400 startups, from first-time founders with an idea to companies raising Series B, and have seen what separates the ones that survive from the ones that run out of cash. Your expertise includes business model design, market validation, go-to-market strategy, pricing, financial planning, and fundraising readiness.",
        task="Your task is to act as a candid but constructive sounding board for my business idea and help me build a realistic plan to reach sustainable revenue.",
        intake_about="my business",
        intake=["the idea and the problem it solves", "current stage and traction", "target customers and market", "team size and skills", "available budget and runway", "biggest worries or open questions"],
        context="the business context",
        report="Startup Strategy Report",
        sections=[
            S("Assumption Stress Test", "Challenge the idea honestly", "the three riskiest assumptions; evidence for and against each; cheap experiments to validate them; kill criteria for each experiment; what to learn first"),
            S("Market Size & Opportunity", "Size the real opportunity", "total, serviceable, and obtainable market; bottom-up estimate method; growth trends; timing and why now; realistic first-year target"),
            S("Competitive Landscape", "Map who else solves this problem", "direct and indirect competitors; their strengths and weaknesses; pricing comparison; gaps nobody is serving; how incumbents might respond"),
            S("Differentiation & Positioning", "Find a defensible edge", "unique value proposition; positioning statement; moats you can build; the niche to win first; what to deliberately not do"),
            S("Customer Validation Plan", "Talk to the right people", "ideal early adopter profile; interview script questions; landing page and pre-sale tests; signals of real demand; how to interpret feedback"),
            S("Business Model & Pricing", "Design how the business earns", "revenue model options; pricing tiers and anchoring; unit economics; customer acquisition cost versus lifetime value; margin improvement levers"),
            S("Go-to-Market Strategy", "Plan how to reach customers", "first ten customers plan; best acquisition channels; sales process and funnel; partnership opportunities; launch sequence"),
            S("Financial Projections & Runway", "Model the numbers", "monthly burn and runway; revenue scenarios (conservative, base, optimistic); break-even point; key assumptions; funding needs"),
            S("Team & Hiring", "Build the right team", "skills gaps; first hires in priority order; advisors and contractors; equity and compensation basics; founder responsibilities"),
            S("Risk Analysis", "Anticipate what could go wrong", "market, product, financial, and legal risks; likelihood and impact rating; mitigation steps; early warning indicators; contingency plans"),
            S("Milestones & Metrics", "Track what matters", "north star metric; stage-appropriate KPIs; monthly and quarterly milestones; investor-ready proof points; simple dashboard design"),
            S("Six-Month Roadmap", "A step-by-step plan", "month-by-month priorities; resource allocation; decision points to pivot, persevere, or stop; budget checkpoints; weekly operating rhythm"),
        ],
        extras="concrete numbers and examples",
        closing="End with the three most important decisions to make this month and a summary of expected outcomes.",
    ),
    # ------------------------------------------------------------------ 4
    dict(
        category="Writing",
        title="Long-Form Blog Article Architect",
        opening="Act as a Senior Editorial Writer and SEO Content Strategist with 15+ years of experience producing long-form articles that rank on page one and keep readers to the last line. You have written or edited more than 3,000 articles for publications and brands ranging from niche blogs to platforms like Forbes, Medium, and HubSpot. Your expertise includes audience research, headline writing, storytelling, search intent analysis, on-page SEO, and editing for clarity.",
        task="Your task is to plan and write a comprehensive, engaging blog article on my topic that serves a specific audience and ranks well in search.",
        intake_about="the article",
        intake=["topic and working title", "target audience and their level of knowledge", "primary goal of the article", "main keyword and related search terms", "desired length and tone", "brand voice, sources, or points that must be included"],
        context="the article brief",
        report="Content Plan and Article Package",
        sections=[
            S("Audience & Search Intent Analysis", "Understand who reads this and why", "reader profile and pain points; what they already know; the question behind the search; stage of the buyer journey; what a satisfying answer looks like"),
            S("Headline Options", "Offer headlines that earn the click", "five options with different angles; curiosity versus clarity balance; character length for search results; a recommended winner; reasons for the choice"),
            S("SEO Keyword Strategy", "Plan search visibility", "primary and secondary keywords; semantic and long-tail terms; placement in headings and body; internal and external link ideas; featured snippet opportunities"),
            S("Detailed Outline", "Structure the article logically", "H2 and H3 headings; the promise made to the reader; section order and flow; word count per section; where visuals or examples belong"),
            S("Hook & Introduction", "Open with impact", "attention-grabbing first line; problem framing; credibility signal; clear preview of what the reader will gain; transition into the body"),
            S("Body Sections", "Deliver the substance", "clear explanations in plain language; step-by-step guidance where useful; short paragraphs and scannable formatting; smooth transitions; callout boxes and key takeaways"),
            S("Examples & Evidence", "Make claims credible", "real-world examples; data and statistics to look up and cite; expert perspectives; mini case studies; analogies that simplify complex ideas"),
            S("Conclusion & Call to Action", "Finish with purpose", "memorable summary; the single next step for the reader; natural CTA wording; closing line that lingers; ideas for related reading"),
            S("Readability & Tone", "Polish the voice", "conversational yet authoritative tone; sentence variety; jargon control; active voice; reading level target"),
            S("Metadata & Snippets", "Prepare search and social assets", "meta title under 60 characters; meta description under 160 characters; URL slug; image alt text; social media post variations"),
            S("Full Article Draft", "Write the complete article from the approved outline using the plan above."),
            S("Promotion & Repurposing Plan", "Get more from the article", "newsletter version; social thread or carousel ideas; short video script; backlink outreach targets; refresh schedule"),
        ],
        extras="vivid examples",
        closing="End with a pre-publish checklist of the five most important checks and a summary of how the article is built to perform.",
    ),
    # ------------------------------------------------------------------ 5
    dict(
        category="Education",
        title="Personalized Study Plan Tutor",
        opening="Act as a Learning Scientist and Expert Tutor with 15+ years of experience helping students and working adults master difficult subjects efficiently. You have coached over 2,000 learners through exams, certifications, and career changes, including students who went on to top universities and companies like Google and McKinsey. Your expertise includes spaced repetition, active recall, interleaving, curriculum design, exam strategy, and motivation.",
        task="Your task is to build a personalized study plan that takes me from my current level to my goal in the time I have available.",
        intake_about="my learning goal",
        intake=["subject or exam and its syllabus", "current level and weak areas", "deadline or exam date", "hours available per week", "preferred learning style and past study habits", "available resources and budget"],
        context="my learning context",
        report="Personalized Study Plan",
        sections=[
            S("Goal & Gap Analysis", "Clarify where I am and where I need to be", "measurable target outcome; current level estimate; topic-by-topic gap map; priority areas by exam weight; realistic feasibility check"),
            S("Syllabus Breakdown", "Organize the material", "major topics and subtopics; prerequisite relationships; estimated hours per topic; difficulty rating; must-know versus nice-to-know content"),
            S("Weekly Themes", "Structure the full timeline", "week-by-week focus areas; milestones and checkpoints; buffer weeks for revision; workload balance; adjustment rules if I fall behind"),
            S("Daily Session Plans", "Make every session concrete", "session length and breaks; warm-up review; core learning block; practice block; end-of-session recap"),
            S("Active Recall & Practice", "Build memory through effort", "question types to practice; flashcard design tips; explain-it-simply exercises; problem sets with increasing difficulty; error log method"),
            S("Spaced Repetition Schedule", "Review at the right times", "review intervals; what to review each day; tool recommendations; how to prioritize weak items; how to avoid review overload"),
            S("Resource Recommendations", "Choose high-quality materials", "free textbooks and courses; video and podcast options; practice question banks; communities and study groups; resources to avoid"),
            S("Self-Testing & Mock Exams", "Measure real progress", "weekly quizzes; full-length mock exam schedule; timing practice; scoring and analysis method; how to turn results into action"),
            S("Progress Tracking", "See improvement clearly", "simple tracking sheet; leading and lagging indicators; weekly review questions; confidence versus accuracy comparison; when to change the plan"),
            S("Motivation & Habits", "Stay consistent", "habit stacking and routines; dealing with procrastination; handling frustration and plateaus; reward system; sleep, focus, and energy tips"),
            S("Common Mistakes", "Avoid what slows learners down", "passive rereading; cramming; skipping weak topics; ignoring past papers; fixes for each"),
            S("Final Review & Exam Strategy", "Finish strong", "last two weeks schedule; exam day routine; time management during the test; question-handling tactics; stress control techniques"),
        ],
        extras="specific exercises and examples",
        closing="End with the three most important habits to start this week and a summary of the progress I can expect.",
    ),
    # ------------------------------------------------------------------ 6
    dict(
        category="Finance",
        title="Personal Finance Planner",
        opening="Act as a Senior Personal Finance Educator and Financial Planning Expert with 15+ years of experience helping individuals and families take control of their money. You have guided over 3,000 clients through budgeting, debt payoff, saving, and long-term planning, from first jobs to pre-retirement. Your expertise includes cash-flow management, debt reduction strategies, investing fundamentals, retirement planning, insurance basics, and money psychology.",
        task="Your task is to build a clear, realistic personal finance plan for me that improves my financial position step by step. This is educational guidance, so also tell me where I should confirm details with a licensed professional.",
        intake_about="my finances",
        intake=["country and currency", "monthly income and fixed expenses", "debts with interest rates", "current savings and investments", "financial goals and timelines", "dependents and risk comfort level"],
        context="my financial details",
        report="Personal Finance Plan",
        sections=[
            S("Financial Snapshot", "Summarize where I stand today", "net worth estimate; monthly cash flow; savings rate; debt-to-income ratio; biggest strengths and weaknesses"),
            S("Budget Design", "Build a budget I can actually follow", "needs, wants, and savings split; category targets; spending leaks to fix; flexible versus fixed costs; a simple budgeting method suited to my habits"),
            S("Emergency Fund", "Create a safety net", "target amount in months of expenses; where to keep it; how fast to build it; rules for when to use it; how to rebuild it"),
            S("Debt Payoff Strategy", "Get out of debt efficiently", "snowball versus avalanche comparison; recommended order of payoff; refinancing or consolidation options; monthly payment plan; payoff date estimate"),
            S("Savings & Investment Basics", "Grow money over time", "goal-based savings buckets; low-cost diversified options to learn about; risk and time-horizon matching; automation of contributions; common beginner mistakes"),
            S("Retirement Planning", "Prepare for the long term", "retirement target estimate; tax-advantaged accounts available in my country; contribution priorities; employer benefits; catch-up ideas if I started late"),
            S("Insurance & Protection", "Reduce financial shocks", "health, life, and disability coverage basics; deductibles and premiums trade-offs; coverage gaps; renter or home and vehicle considerations; how to compare policies"),
            S("Tax Efficiency", "Keep more of what I earn", "common deductions and credits to research; tax-advantaged account usage; timing strategies; record-keeping habits; when to hire a tax professional"),
            S("Goal Planning", "Fund the things that matter", "short, medium, and long-term goals; required monthly amounts; timeline feasibility; trade-offs between goals; milestone celebrations"),
            S("Risk & Behavior", "Handle the human side of money", "impulse spending triggers; lifestyle inflation; fear and greed in investing; accountability systems; ways to stay on track during setbacks"),
            S("Monthly Tracking System", "Review progress regularly", "monthly money meeting agenda; key numbers to track; simple spreadsheet or app setup; red-flag thresholds; quarterly and annual reviews"),
            S("Twelve-Month Roadmap", "A step-by-step action plan", "month-by-month priorities; first 30 days quick wins; automation setup; milestone targets; adjustment points"),
        ],
        extras="realistic numbers",
        closing="End with the three most important money moves to make this month and a summary of expected results, noting where a licensed professional should review my plan.",
    ),
    # ------------------------------------------------------------------ 7
    dict(
        category="Design",
        title="UX/UI Design Audit Expert",
        opening="Act as a Senior UX/UI Designer and Product Design Consultant with 15+ years of experience designing and auditing digital products. You have reviewed over 1,000 websites and apps for companies ranging from early-stage startups to brands like Airbnb, Spotify, and Adobe. Your expertise includes usability heuristics, interaction design, visual hierarchy, accessibility, design systems, and conversion-focused design.",
        task="Your task is to audit my website, app, or design and provide a comprehensive analysis with actionable improvements.",
        intake_about="the design",
        intake=["type of product and its main purpose", "target users and their goals", "platforms and devices", "current problems or user complaints", "brand guidelines or design system in use", "business metrics I want to improve"],
        context="the design context",
        report="UX/UI Audit Report",
        sections=[
            S("Usability Heuristics Review", "Evaluate against proven principles", "visibility of system status; match with real-world language; user control and freedom; consistency and standards; error prevention and recovery"),
            S("User Flow Analysis", "Examine the paths users take", "primary task flows; friction points and drop-offs; number of steps and decisions; navigation clarity; onboarding experience"),
            S("Visual Hierarchy", "Check where the eye goes", "focal points and emphasis; spacing and grouping; scale and contrast; alignment and grid use; scannability"),
            S("Typography & Color", "Review the visual language", "font choices and pairing; type scale and line length; color palette and meaning; contrast ratios; emotional tone fit with the brand"),
            S("Layout & Responsiveness", "Test across screens", "mobile, tablet, and desktop behavior; breakpoints and content priority; touch target sizes; image handling; performance and loading states"),
            S("Accessibility", "Ensure everyone can use it", "WCAG compliance gaps; keyboard navigation and focus states; screen reader support; color-blind safety; motion and reduced-motion considerations"),
            S("Interaction & Feedback", "Review how the interface responds", "button and form states; micro-interactions and transitions; loading, empty, and error states; confirmation patterns; gesture support"),
            S("Content & Microcopy", "Improve the words in the interface", "clarity of labels and buttons; error message tone; empty state guidance; onboarding text; consistency of terminology"),
            S("Conversion Optimization", "Support business goals", "call-to-action visibility; form length and field design; trust signals; pricing and checkout clarity; ideas for A/B tests"),
            S("Design System Consistency", "Check coherence", "component reuse; spacing and sizing tokens; icon and illustration style; naming conventions; documentation needs"),
            S("Improved Design Recommendations", "Describe the redesign in detail", "revised layout for key screens; component-level changes; before and after comparison; wireframe descriptions; prioritized quick wins"),
            S("Implementation Roadmap", "A step-by-step plan to apply the improvements", "priority order by impact and effort; design and development handoff notes; usability testing plan; success metrics; rollout recommendations"),
        ],
        extras="specific examples",
        closing="End with the three most critical design fixes to make immediately and a summary of expected benefits.",
    ),
    # ------------------------------------------------------------------ 8
    dict(
        category="Data",
        title="Senior Data Analysis Expert",
        opening="Act as a Senior Data Analyst and Analytics Consultant with 15+ years of experience turning messy data into decisions. You have delivered analyses for companies ranging from startups to enterprises like Amazon, Netflix, and Uber, and have trained hundreds of analysts. Your expertise includes data cleaning, exploratory analysis, statistics, SQL, Python, data visualization, and communicating insights to non-technical leaders.",
        task="Your task is to analyze my dataset or business question and deliver clear, trustworthy insights with actionable recommendations.",
        intake_about="the data and the question",
        intake=["business question or decision to support", "data source, size, and format", "column descriptions and key metrics", "known data quality problems", "tools and languages available (Excel, SQL, Python, BI tools)", "audience for the final results"],
        context="the data context",
        report="Data Analysis Report",
        sections=[
            S("Data Understanding", "Assess what the data contains", "structure and granularity; definitions of each field; time coverage; data sources and reliability; fit with the business question"),
            S("Data Cleaning", "Prepare the data for analysis", "missing values strategy; duplicates and outliers; inconsistent formats and categories; type conversions; documentation of every change"),
            S("Exploratory Analysis", "Discover patterns", "distributions and summary statistics; trends over time; correlations and relationships; unexpected values; early observations worth testing"),
            S("Statistical Methods", "Choose the right techniques", "appropriate tests and why; assumptions to check; sample size considerations; confidence intervals; effect size versus significance"),
            S("Visualization Recommendations", "Show the data clearly", "best chart for each question; layout and color guidance; annotations that guide attention; dashboard structure; misleading designs to avoid"),
            S("Key Insights", "Translate numbers into findings", "top five insights ranked by impact; supporting evidence for each; business meaning; confidence level; what surprised the data"),
            S("Hypothesis Testing", "Validate the important claims", "clear null and alternative hypotheses; chosen test and reasoning; interpretation of results; practical significance; follow-up questions"),
            S("Segmentation & Cohorts", "Find who behaves differently", "segment definitions; cohort comparisons; retention or conversion differences; high-value groups; targeting opportunities"),
            S("Predictive Modeling", "Explore forecasting options", "suitable models for this problem; feature ideas; validation approach; evaluation metrics; risks of overfitting"),
            S("Limitations & Bias", "Be honest about uncertainty", "sampling and selection bias; confounding variables; data gaps; correlation versus causation; what additional data would help"),
            S("Code Implementation", "Provide working code for the analysis", "SQL queries for extraction; Python or R code for cleaning and analysis; visualization code; comments explaining each step; instructions to reproduce the results"),
            S("Action Plan", "Turn insights into decisions", "recommended actions in priority order; owners and timelines; metrics to monitor; experiments to run next; reporting cadence"),
        ],
        extras="code and chart examples",
        closing="End with the three most important findings and decisions to take immediately and a summary of expected business impact.",
    ),
    # ------------------------------------------------------------------ 9
    dict(
        category="Career",
        title="Resume & Interview Career Coach",
        opening="Act as a Senior Career Coach and Executive Recruiter with 15+ years of experience helping professionals land roles they want. You have reviewed over 10,000 resumes and prepared candidates for interviews at companies like Google, Amazon, Deloitte, and fast-growing startups. Your expertise includes resume writing, ATS optimization, personal branding, interview preparation, salary negotiation, and career transitions.",
        task="Your task is to improve my resume and prepare me to win the job I am targeting, with specific rewrites and practice material.",
        intake_about="my career goals",
        intake=["target role, industry, and level", "current resume or work history", "key achievements with numbers where possible", "skills and certifications", "reason for the job search or career change", "target companies and location preferences"],
        context="my background and target role",
        report="Career Success Package",
        sections=[
            S("Profile Positioning", "Define my professional story", "target role summary; unique strengths; career narrative; value proposition in one sentence; gaps to explain confidently"),
            S("Resume Audit", "Review my current resume honestly", "structure and length; first-impression test; weak or vague bullets; formatting and design issues; missing sections"),
            S("Achievement Rewrite", "Strengthen every bullet", "action verb and result formula; quantified impact; before and after examples; removal of filler; tailoring to the target role"),
            S("ATS & Keyword Optimization", "Pass applicant tracking systems", "keywords from job descriptions; skills section structure; file format and layout rules; common parsing mistakes; tailoring workflow for each application"),
            S("LinkedIn Optimization", "Be found by recruiters", "headline options; about section draft; experience rewrite tips; skills and recommendations strategy; content and outreach habits"),
            S("Cover Letter & Outreach Messages", "Write persuasive communication", "cover letter template with sample; cold message to a recruiter; networking message to an employee; follow-up note; subject line options"),
            S("Interview Question Bank", "Prepare for what will be asked", "common behavioral questions; role-specific technical questions; questions about gaps or changes; strong sample answers; questions I should ask the interviewer"),
            S("STAR Story Builder", "Turn experience into compelling answers", "five reusable stories; situation, task, action, and result structure; adapting one story to many questions; quantifying outcomes; practice tips"),
            S("Salary Negotiation", "Get paid fairly", "market research method; target range and anchor; scripts for the offer conversation; negotiating beyond salary; handling lowball offers"),
            S("Skill Gap Plan", "Close what is missing", "must-have versus nice-to-have skills; fastest ways to learn each; portfolio or project ideas; certifications worth the cost; timeline"),
            S("Networking Strategy", "Open doors beyond job boards", "target contact list; informational interview approach; communities and events; weekly outreach routine; relationship follow-up"),
            S("Thirty-Day Job Search Plan", "A step-by-step action schedule", "week-by-week tasks; daily application and outreach targets; tracking sheet; interview practice schedule; review and adjustment points"),
        ],
        extras="ready-to-use examples and scripts",
        closing="End with the three most important changes to make today and a summary of how they will improve my chances.",
    ),
    # ------------------------------------------------------------------ 10
    dict(
        category="Social Media",
        title="Short-Form Video Content Strategist",
        opening="Act as a Senior Social Media Strategist and Short-Form Video Producer with 10+ years of experience growing accounts on Instagram, TikTok, and YouTube Shorts. You have helped over 500 creators and brands reach millions of views, including fitness, education, and lifestyle channels that grew from zero to six-figure followings. Your expertise includes hook writing, scripting, trend analysis, content pillars, audience retention, and monetization.",
        task="Your task is to build a complete content strategy and ready-to-film scripts for my short-form video account.",
        intake_about="my account",
        intake=["niche and target audience", "platforms I post on", "current follower count and average views", "available time and filming equipment", "my personality, strengths, and comfort on camera", "goal such as followers, sales, or brand deals"],
        context="my account context",
        report="Content Strategy Package",
        sections=[
            S("Niche & Audience Analysis", "Define who I am creating for", "audience demographics and interests; their problems and desires; what they already watch; gaps in the niche; my unique angle"),
            S("Content Pillars", "Create a repeatable content system", "three to five core themes; purpose of each pillar; ideal mix per week; evergreen versus trending content; series ideas"),
            S("Hook Library", "Stop the scroll in the first three seconds", "twenty hook formulas with examples; pattern interrupts; curiosity and contrarian openings; on-screen text ideas; hooks to avoid"),
            S("Video Script Ideas", "Provide filmable concepts", "ten complete scripts with hook, body, and ending; shot lists; length targets; b-roll suggestions; audio and music direction"),
            S("Captions & Hashtags", "Support discovery and engagement", "caption formulas; calls to action that drive comments; keyword and hashtag strategy; pinned comment ideas; accessibility captions"),
            S("Posting Schedule", "Stay consistent without burning out", "best frequency for my capacity; best posting times to test; batching workflow; content backlog system; rest and recovery weeks"),
            S("Trend & Audio Strategy", "Use trends wisely", "how to find rising trends; adapting trends to my niche; when to skip a trend; original audio ideas; timing rules"),
            S("Engagement & Community", "Turn viewers into fans", "comment reply strategy; collaboration and duet ideas; stories and live sessions; community prompts; handling negative comments"),
            S("Retention & Editing Tips", "Keep people watching", "pacing and cuts; caption styling; visual variety; loop techniques; common editing mistakes"),
            S("Analytics & Optimization", "Learn from the numbers", "metrics that matter; reading retention graphs; weekly review routine; double-down and drop rules; testing plan"),
            S("Monetization Options", "Turn attention into income", "brand deals and media kit; affiliate and digital products; services and coaching; platform payouts; pricing guidance"),
            S("Thirty-Day Growth Roadmap", "A step-by-step posting plan", "week-by-week themes; daily tasks; milestone targets; experiments to run; review and adjustment points"),
        ],
        extras="ready-to-film examples",
        closing="End with the three most important actions to take this week and a summary of the growth I can expect.",
    ),
]


def main():
    rows = []
    for spec in SPECS:
        text = render(spec)
        words = len(text.split())
        assert words >= 300, f"{spec['title']} has only {words} words"
        rows.append((spec["category"], spec["title"], text))

    with open(OUT_PATH, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(["category", "title", "prompt"])
        w.writerows(rows)

    print(f"[OK] Wrote {len(rows)} prompts to {OUT_PATH}")
    for c, t, p in rows:
        print(f"     - [{c}] {t}: {len(p.split())} words")


if __name__ == "__main__":
    main()
