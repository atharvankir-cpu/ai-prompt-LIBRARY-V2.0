"""
import_prompts.py - Bulk-import prompts into aivault.db from a CSV or JSON file.

Usage:
    python import_prompts.py my_prompts.csv            # add to existing prompts
    python import_prompts.py my_prompts.json --replace # wipe the table first (removes dummy data)

CSV  : needs a header row with columns: category,title,prompt
JSON : a list like [{"category": "...", "title": "...", "prompt": "..."}, ...]

Rows with an empty field are skipped. Exact duplicates (same category + title
+ prompt) are skipped, so re-running the same file will not double your data.
"""
import argparse
import csv
import json
import os
import sqlite3
import sys

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DB_PATH = os.path.join(BASE_DIR, "aivault.db")

csv.field_size_limit(min(sys.maxsize, 2**31 - 1))  # allow very long prompt cells


def read_rows(path):
    ext = os.path.splitext(path)[1].lower()
    if ext == ".json":
        with open(path, "r", encoding="utf-8-sig") as f:
            data = json.load(f)
        if not isinstance(data, list):
            sys.exit("[ERROR] JSON must be a list of objects.")
        return data
    if ext == ".csv":
        with open(path, "r", encoding="utf-8-sig", newline="") as f:
            reader = csv.DictReader(f)
            needed = {"category", "title", "prompt"}
            got = {(h or "").strip().lower() for h in (reader.fieldnames or [])}
            if not needed.issubset(got):
                sys.exit(f"[ERROR] CSV header must include: category,title,prompt (found: {sorted(got)})")
            return [{(k or "").strip().lower(): v for k, v in row.items()} for row in reader]
    sys.exit("[ERROR] Only .csv and .json files are supported.")


def clean(value):
    return str(value).strip() if value is not None else ""


def main():
    ap = argparse.ArgumentParser(description="Bulk import prompts into aivault.db")
    ap.add_argument("file", help="path to a .csv or .json file")
    ap.add_argument("--replace", action="store_true", help="delete all existing prompts first")
    args = ap.parse_args()

    if not os.path.exists(args.file):
        sys.exit(f"[ERROR] File not found: {args.file}")

    raw = read_rows(args.file)
    rows, skipped_empty = [], 0
    for r in raw:
        cat, title, prompt = clean(r.get("category")), clean(r.get("title")), clean(r.get("prompt"))
        if not (cat and title and prompt):
            skipped_empty += 1
            continue
        rows.append((cat, title, prompt))

    conn = sqlite3.connect(DB_PATH)
    try:
        cur = conn.cursor()
        cur.execute(
            """CREATE TABLE IF NOT EXISTS prompts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                category TEXT NOT NULL,
                title TEXT NOT NULL,
                prompt TEXT NOT NULL)"""
        )
        cur.execute("CREATE INDEX IF NOT EXISTS idx_prompts_category ON prompts(category)")

        if args.replace:
            cur.execute("DELETE FROM prompts")
            cur.execute("DELETE FROM sqlite_sequence WHERE name = 'prompts'")

        existing = set(cur.execute("SELECT category, title, prompt FROM prompts"))
        new_rows, seen = [], set(existing)
        for row in rows:
            if row not in seen:
                seen.add(row)
                new_rows.append(row)

        cur.executemany("INSERT INTO prompts (category, title, prompt) VALUES (?, ?, ?)", new_rows)
        conn.commit()

        total = cur.execute("SELECT COUNT(*) FROM prompts").fetchone()[0]
        print(f"[OK] Imported : {len(new_rows)}")
        print(f"     Duplicates skipped : {len(rows) - len(new_rows)}")
        print(f"     Incomplete rows skipped : {skipped_empty}")
        print(f"     Total prompts in database : {total}")
    except sqlite3.Error as exc:
        conn.rollback()
        sys.exit(f"[ERROR] Import failed, nothing was saved: {exc}")
    finally:
        conn.close()


if __name__ == "__main__":
    main()
