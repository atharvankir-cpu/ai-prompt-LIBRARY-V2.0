"""
build_10k.py - Generates 10,000 prompts (100 categories x 100 prompts) in the AI Vault master template.

Structure:
    100 categories  x  10 subjects each  x  10 prompt types  =  10,000 unique prompts

Usage:
    python setup_db.py            # (optional) makes sure the table exists
    python build_10k.py           # replaces everything in aivault.db with the 10,000 prompts
    python build_10k.py --append  # keeps existing prompts and adds these
    python build_10k.py --csv     # ALSO writes prompts_10k.csv

Every prompt follows the master template:
    Act as... -> Task -> Intake questions -> 12 numbered report sections -> closing line.
"""
import argparse
import csv
import os
import sqlite3

from build_prompts import S, join_items

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DB_PATH = os.path.join(BASE_DIR, "aivault.db")
CSV_PATH = os.path.join(BASE_DIR, "prompts_10k.csv")

# Categories where advice touches health, money, or law: add a "consult a professional" note.
SENSITIVE = {
    "Finance & Investing", "Personal Finance", "Legal & Contracts", "Fitness & Workouts",
    "Nutrition & Meal Planning", "Healthy Habits", "Health & Medical Education",
    "Stress & Mindfulness", "Parenting", "Pet Care", "Beauty & Skincare",
}
PRO_NOTE = " This is educational guidance, so also tell me when I should consult a qualified professional."

# --------------------------------------------------------------------------------------
# THE 10 PROMPT TYPES (each one has the full 12-section structure)
# {s} = subject, {c} = category
# --------------------------------------------------------------------------------------
FRAMEWORKS = [
    dict(
        title="Strategy Planner", role="Strategist",
        task="Your task is to design a complete, practical {s} strategy for me that takes me from my current position to my goal.",
        about="my situation",
        intake=["my goal and timeline", "my current level of experience with {s}", "available budget, time, and tools", "target audience or people involved", "what I have already tried and the results", "main obstacles or concerns"],
        context="my situation", report="{s} Strategy Report",
        sections=[
            S("Goal Definition", "Clarify what success looks like", "measurable objectives; success metrics; timeline and milestones; constraints and assumptions; what is out of scope"),
            S("Current State Assessment", "Evaluate where I stand today", "strengths to build on; gaps and weaknesses; resources already available; benchmarks from peers or competitors; quick opportunities"),
            S("Core Strategy", "Define the winning approach", "guiding principles; key strategic choices; priorities and trade-offs; unique advantages to leverage; what to avoid"),
            S("Audience & Stakeholder Insights", "Understand who this serves", "ideal audience profile; needs, pains, and motivations; behavior patterns; where to reach them; messaging that resonates"),
            S("Tactics & Methods", "Choose proven {s} tactics", "beginner-friendly methods; advanced techniques; tools and platforms; examples of each tactic in action; effort versus impact ranking"),
            S("Resource & Budget Plan", "Allocate time, money, and people", "budget breakdown; weekly time commitment; tools and software; outsourcing versus doing it myself; cost-saving options"),
            S("Execution Plan", "Turn the strategy into tasks", "phases and workstreams; weekly task lists; dependencies; responsibilities; templates and checklists"),
            S("Risk Management", "Anticipate problems before they happen", "top risks; early warning signs; mitigation steps; backup plans; common failure patterns in {s}"),
            S("Metrics & Tracking", "Measure progress honestly", "leading and lagging indicators; benchmarks; tracking tools; review cadence; decision rules for what to change"),
            S("Examples & Templates", "Provide ready-to-use material", "sample plans; example scripts, checklists, or templates; before and after illustrations; a worked example for my case; tips for adapting each"),
            S("Optimization Loop", "Improve continuously", "weekly review questions; experiments to run; scaling what works; stopping what does not; knowledge capture"),
            S("90-Day Roadmap", "A step-by-step plan to execute", "week-by-week milestones; priority order of actions; effort and complexity estimates; checkpoints; long-term next steps"),
        ],
        extras="practical examples",
        closing="End with the three most important actions to take this week and a summary of expected results.",
    ),
    dict(
        title="Audit Expert", role="Auditor",
        task="Your task is to audit my current {s} work, setup, or results and provide a comprehensive analysis with actionable improvements.",
        about="what I have", intake=["what I am working on and its purpose", "current results or performance", "tools, methods, and standards in use", "target audience or goals", "known problems or complaints", "areas I want you to focus on"],
        context="the full picture", report="{s} Audit Report",
        sections=[
            S("Executive Summary", "Give the big picture first", "overall rating; top strengths; top weaknesses; biggest opportunity; urgency level"),
            S("Fundamentals Review", "Check the basics of {s}", "core principles applied correctly; missing essentials; common beginner errors; consistency of approach; alignment with the stated goal"),
            S("Quality Assessment", "Evaluate the quality of the work", "accuracy and completeness; clarity and professionalism; originality and differentiation; attention to detail; overall quality score"),
            S("Efficiency & Performance", "Measure how well it performs", "results versus goals; time and cost efficiency; bottlenecks; wasted effort; performance benchmarks"),
            S("Strengths", "Identify what is working", "elements to keep; practices worth repeating; competitive advantages; areas of real skill; ways to amplify them"),
            S("Weaknesses & Gaps", "Identify what is holding things back", "critical gaps; recurring mistakes; missing knowledge or tools; weak links in the process; impact of each weakness"),
            S("Best Practice Comparison", "Compare against professional standards", "industry standards; expert-level approaches; what top performers do differently; tools they use; realistic target level"),
            S("Risks & Compliance", "Check for hidden problems", "technical, financial, and reputational risks; rules or guidelines to follow; safety or quality concerns; dependency risks; mitigation steps"),
            S("Quick Wins", "Find fast improvements", "changes under one hour; changes under one day; low-cost fixes; high-visibility improvements; expected impact of each"),
            S("Strategic Improvements", "Plan deeper changes", "structural changes; skill development; tool upgrades; process redesign; long-term advantages"),
            S("Improved Version", "Provide an improved version or revised plan with all recommended changes applied."),
            S("Implementation Roadmap", "A step-by-step plan to apply the improvements", "priority order of fixes; estimated effort and complexity; testing strategy for changes; follow-up audit schedule"),
        ],
        extras="specific examples",
        closing="End with the three most critical improvements to make immediately and a summary of expected benefits.",
    ),
    dict(
        title="Learning Roadmap Coach", role="Coach",
        task="Your task is to build a personalized learning roadmap that takes me from my current level in {s} to confident, practical skill.",
        about="my learning goal", intake=["my current level and prior experience", "learning goal and deadline", "hours available per week", "preferred learning style", "budget for courses or tools", "how I plan to use the skill"],
        context="my learning context", report="{s} Learning Roadmap",
        sections=[
            S("Skill Assessment", "Find my starting point", "quick diagnostic questions; current strengths; knowledge gaps; realistic goal for my timeline; level definitions from beginner to advanced"),
            S("Learning Path Overview", "Show the big picture", "stages of mastery; skills in each stage; estimated hours per stage; milestones; how the stages connect"),
            S("Core Concepts", "Teach the foundations of {s}", "the most important ideas explained simply; how the concepts relate; analogies and examples; what to learn first; what to postpone"),
            S("Essential Terminology", "Build a working vocabulary", "twenty key terms with plain definitions; commonly confused terms; jargon used by professionals; memory tips; how to use each term in context"),
            S("Week-by-Week Plan", "Structure the schedule", "weekly themes; daily practice blocks; review sessions; flexible catch-up weeks; adjustments if I fall behind"),
            S("Hands-On Projects", "Learn by building", "beginner project; intermediate project; advanced capstone project; step-by-step guidance for the first one; how to showcase results"),
            S("Practice Exercises", "Strengthen skills through repetition", "daily drills; graded difficulty; self-check questions; answer explanations; spaced review plan"),
            S("Resources", "Recommend high-quality material", "free courses and videos; books and guides; practice platforms; communities and mentors; resources to avoid"),
            S("Common Mistakes", "Avoid what slows learners down", "typical beginner errors; misconceptions about {s}; bad habits to prevent; warning signs of poor progress; fixes for each"),
            S("Progress Checkpoints", "Measure improvement", "skill tests; project reviews; confidence ratings; benchmarks per stage; when to move to the next stage"),
            S("Advanced Next Steps", "Plan beyond the basics", "specializations; professional or certification paths; advanced techniques; teaching others; building a reputation"),
            S("Motivation & Habits", "Stay consistent", "habit stacking; handling plateaus; accountability methods; reward system; energy and focus tips"),
        ],
        extras="specific exercises and examples",
        closing="End with the three most important things to do today and a summary of what I will be able to do at each stage.",
    ),
    dict(
        title="Implementation Guide", role="Implementation Specialist",
        task="Your task is to guide me step by step through implementing {s} in a real project, from preparation to a working result.",
        about="my project", intake=["what I want to build or achieve", "my starting point and existing setup", "tools, platforms, or materials available", "deadline and budget", "my skill level", "constraints or requirements"],
        context="the project context", report="{s} Implementation Guide",
        sections=[
            S("Requirements Definition", "Clarify exactly what is needed", "the desired end result; must-have versus nice-to-have features; constraints; success criteria; assumptions to confirm"),
            S("Preparation Checklist", "Get ready before starting", "knowledge to review; materials and accounts needed; workspace setup; backup and safety steps; time to block out"),
            S("Setup & Tools", "Choose and prepare the right tools", "recommended tools with alternatives; free versus paid options; installation or setup steps; configuration tips; compatibility checks"),
            S("Step-by-Step Process", "Lay out the full workflow", "numbered stages from start to finish; purpose of each stage; expected output of each stage; time per stage; decision points"),
            S("Detailed Instructions", "Explain every step clearly", "exact actions to take; settings and values to use; examples at each stage; screenshots or diagrams to create; shortcuts for faster work"),
            S("Quality Checks", "Verify work as you go", "checkpoints after each stage; standards to meet; self-review questions; common signs something is wrong; how to correct early"),
            S("Common Errors & Fixes", "Handle problems quickly", "the ten most common errors in {s}; why each happens; fast fixes; how to avoid repeating them; when to start over"),
            S("Variations & Alternatives", "Adapt to different situations", "simpler approach; advanced approach; low-budget approach; approach for teams; trade-offs of each"),
            S("Time & Cost Estimates", "Plan resources realistically", "time estimate per stage; cost breakdown; skills that may need outside help; buffers for delays; ways to save"),
            S("Testing & Validation", "Confirm that it works", "test scenarios; acceptance criteria; feedback from real users or peers; performance or quality measures; final review"),
            S("Maintenance & Next Steps", "Keep the result working", "regular upkeep tasks; update schedule; improvements to consider; how to document the work; how to scale or repeat"),
            S("Final Checklist", "Finish with a complete verification list", "pre-launch checks; documentation complete; backups made; stakeholders informed; success review date"),
        ],
        extras="concrete examples",
        closing="End with the three most critical things to get right first and a summary of what a successful result looks like.",
    ),
    dict(
        title="Problem-Solving Expert", role="Troubleshooter",
        task="Your task is to diagnose the problem I am facing with {s} and guide me to a lasting solution.",
        about="the problem", intake=["a description of the problem and when it started", "what I expected versus what actually happened", "what I have already tried", "relevant details, settings, or examples", "urgency and impact", "tools or constraints I have"],
        context="the problem details", report="{s} Diagnosis & Solution Report",
        sections=[
            S("Problem Restatement", "Confirm the exact issue", "a clear summary in my own terms; expected versus actual result; scope and impact; what is unknown; success definition"),
            S("Symptom Analysis", "Study the evidence", "patterns in when it happens; what changed recently; what always works and what never does; clues from past attempts; severity rating"),
            S("Likely Root Causes", "List what could be wrong", "top five hypotheses ranked by probability; evidence for and against each; common causes in {s}; hidden or indirect causes; what each cause would predict"),
            S("Diagnostic Process", "Narrow down the cause", "tests in logical order; what each test proves; how to isolate variables; tools for diagnosis; how to record results"),
            S("Quick Fixes", "Restore progress fast", "temporary workarounds; low-risk fixes to try first; expected result of each; how to undo each change; time required"),
            S("Permanent Solutions", "Fix the real cause", "long-term fix for each root cause; effort and cost; side effects to watch; better alternatives; recommended choice"),
            S("Step-by-Step Fix Instructions", "Walk through the recommended fix", "numbered actions; exact settings or wording; checks after each step; mistakes to avoid; rollback plan"),
            S("Verification", "Confirm the problem is solved", "tests to run; success indicators; monitoring period; how to catch a recurrence; documentation of the fix"),
            S("Prevention", "Stop it from returning", "habits and routines; checklists; monitoring or alerts; training or skill gaps to close; system improvements"),
            S("Edge Cases & Warnings", "Handle special situations", "unusual variations of the problem; safety or data-loss warnings; things that look like fixes but are not; limits of this approach; when assumptions break"),
            S("When to Get Expert Help", "Know your limits", "signs the problem is beyond DIY; what kind of professional to contact; information to bring; questions to ask; cost expectations"),
            S("Follow-Up Plan", "Make sure it stays fixed", "check-in schedule; metrics to watch; lessons learned log; improvements to the process; final review"),
        ],
        extras="clear examples",
        closing="End with the three most likely causes ranked by probability and a summary of the fastest path to a fix.",
    ),
    dict(
        title="Toolkit Builder", role="Toolkit Designer",
        task="Your task is to create a ready-to-use {s} toolkit of templates, checklists, and frameworks that I can apply immediately.",
        about="my needs", intake=["my goal and use case", "the audience or clients I work with", "my experience level", "preferred format (documents, spreadsheets, slides)", "tools I already use", "any brand or style requirements"],
        context="my needs", report="{s} Toolkit",
        sections=[
            S("Toolkit Overview", "Explain what is included", "list of every tool; when to use each; who each is for; time saved by each; recommended order of use"),
            S("Planning Template", "Provide a reusable planning sheet", "goal and scope fields; timeline section; resources section; risks section; review section"),
            S("Checklist Collection", "Provide practical checklists", "pre-start checklist; quality checklist; launch or delivery checklist; weekly maintenance checklist; final review checklist"),
            S("Process Frameworks", "Provide repeatable processes", "step-by-step workflow for {s}; decision points; roles and responsibilities; handoff rules; improvement loop"),
            S("Decision Frameworks", "Help me choose well", "criteria scoring matrix; priority matrix; go or no-go rules; trade-off worksheet; example completed"),
            S("Communication Templates", "Provide ready-to-send wording", "email templates; message scripts; meeting agenda; status update format; feedback request wording"),
            S("Tracking Sheets", "Provide ways to track progress", "columns and fields to include; formulas or scoring ideas; weekly review layout; dashboard summary; example rows"),
            S("Worked Examples", "Show the tools in action", "a completed example for a beginner; a completed example for an advanced user; annotations explaining each choice; common variations; lessons from each"),
            S("Quick Reference Guide", "Provide a one-page summary", "key rules of {s}; formulas or shortcuts; do and do-not list; glossary; where to look for more"),
            S("Customization Guide", "Adapt the toolkit to me", "what to change first; how to match my brand or style; how to scale for teams; how to simplify; version control tips"),
            S("Common Pitfalls", "Avoid misusing the toolkit", "over-planning; skipping reviews; copying without adapting; ignoring metrics; fixes for each"),
            S("Usage Roadmap", "Show how to adopt the toolkit", "week one setup; first month routine; quarterly review; training others; improvement ideas"),
        ],
        extras="fill-in-the-blank templates",
        closing="End with a short guide on which three tools to use first and a summary of how the toolkit saves time.",
    ),
    dict(
        title="Optimization Expert", role="Optimization Consultant",
        task="Your task is to analyze and optimize my {s} approach so I get better results with less effort.",
        about="my current approach", intake=["my current process and results", "target improvements", "key metrics I track", "resources and constraints", "past optimization attempts", "the timeline for results"],
        context="my current approach", report="{s} Optimization Report",
        sections=[
            S("Baseline Analysis", "Measure the starting point", "current performance numbers; time and cost spent; quality level; data gaps; baseline score"),
            S("Bottleneck Identification", "Find what slows things down", "slowest steps; most expensive steps; recurring errors; dependency delays; the single biggest constraint"),
            S("Efficiency Opportunities", "Do the same work faster", "steps to remove; steps to combine; steps to reorder; batching ideas; time saved by each"),
            S("Automation Opportunities", "Let tools do repetitive work", "tasks worth automating; recommended tools; setup effort; risks of automation; expected savings"),
            S("Cost Reduction", "Spend smarter", "unnecessary expenses; cheaper alternatives; negotiation or bundling options; value-per-dollar ranking; savings estimate"),
            S("Quality Improvements", "Raise the standard of results", "quality metrics; error prevention; review steps; skill upgrades; consistency measures"),
            S("Experiments & Tests", "Improve through evidence", "hypotheses to test; test design; sample size and duration; success thresholds; how to apply winners"),
            S("Tools & Systems", "Build a supportive setup", "recommended tools for {s}; integrations; templates and shortcuts; data tracking; learning curve of each"),
            S("Benchmarking", "Compare with the best", "typical performance ranges; top-performer habits; gaps versus benchmarks; realistic targets; how to keep benchmarks current"),
            S("Scaling Plan", "Grow without breaking things", "what scales and what does not; capacity limits; delegation points; systems needed; growth stages"),
            S("Risks & Trade-offs", "Understand the costs of change", "quality versus speed; short-term versus long-term effects; hidden risks; reversibility; how to protect results"),
            S("Implementation Roadmap", "A step-by-step plan to apply the changes", "priority order by impact and effort; timeline; owners and resources; measurement checkpoints; review schedule"),
        ],
        extras="before and after examples",
        closing="End with the three optimizations that deliver the biggest gains fastest and a summary of expected improvements.",
    ),
    dict(
        title="Decision Advisor", role="Advisor",
        task="Your task is to help me make a confident, well-reasoned decision about {s} by comparing my options objectively.",
        about="my decision", intake=["the decision I need to make", "the options I am considering", "my must-have requirements", "my budget and timeline", "my priorities and deal-breakers", "who else is affected by the outcome"],
        context="my decision context", report="{s} Decision Report",
        sections=[
            S("Decision Framing", "Define the real question", "the decision in one sentence; what is at stake; deadline; reversible versus irreversible; who decides"),
            S("Evaluation Criteria", "Decide how to judge options", "must-have criteria; nice-to-have criteria; weighting of each; measurable indicators; criteria I may be forgetting"),
            S("Options Overview", "Describe each option fairly", "what each option is; who it suits best; typical cost; typical timeline; main assumptions behind it"),
            S("Side-by-Side Comparison", "Compare options on equal terms", "a comparison table; scores per criterion; weighted totals; standout differences; ties and close calls"),
            S("Pros & Cons", "List honest advantages and drawbacks", "main benefits; main drawbacks; short-term versus long-term; effect on other areas of my life or work; what experts usually say about {s}"),
            S("Cost-Benefit Analysis", "Compare value for money", "upfront costs; ongoing costs; expected benefits; payback period; non-financial value"),
            S("Risk Assessment", "Evaluate what could go wrong", "main risks of each option; likelihood and impact; early warning signs; how to reduce each risk; worst-case outcome"),
            S("Scenario Analysis", "Test the decision against the future", "best case; expected case; worst case; what would change the ranking; sensitivity to key assumptions"),
            S("Hidden Factors", "Surface what is easy to miss", "emotional factors; opportunity cost; second-order effects; biases that may affect me; questions to ask others"),
            S("Recommendation", "Give a clear recommendation", "recommended option and reasoning; confidence level; conditions under which another option wins; what to verify first; runner-up"),
            S("Implementation Plan", "Turn the decision into action", "first steps; timeline; resources needed; communication to others; checkpoints"),
            S("Review & Exit Plan", "Stay flexible after deciding", "success metrics; review date; signals to change course; how to exit or switch; lessons to record"),
        ],
        extras="clear comparisons",
        closing="End with your top recommendation with reasoning, the conditions that would change it, and a summary of next steps.",
    ),
    dict(
        title="Research Analyst", role="Research Analyst",
        task="Your task is to research and analyze {s} for me, covering best practices, successful approaches, and how others handle it, using only information you can stand behind and clearly marking anything uncertain or illustrative.",
        about="the research", intake=["my research question or goal", "the scope and depth needed", "region or market of interest", "specific examples or competitors to include", "how I will use the research", "preferred format and length"],
        context="the research brief", report="{s} Research Report",
        sections=[
            S("Research Objectives", "Frame what we need to learn", "core questions; scope and boundaries; definitions of key terms; success criteria; assumptions"),
            S("Landscape Overview", "Map the field", "what {s} is and how it works; main approaches or schools of thought; key players or sources; how it has evolved; current state"),
            S("Key Concepts", "Explain what matters most", "foundational ideas; important frameworks; essential terminology; common misunderstandings; how the concepts connect"),
            S("Best Practices", "Summarize what works", "widely accepted methods; expert recommendations; step-by-step highlights; conditions where each works; evidence level"),
            S("Case Studies", "Show approaches in practice, labeled as real or illustrative", "two or three examples; context of each; what was done; results; lessons"),
            S("Peer & Competitor Analysis", "Compare how others approach it", "main alternatives; strengths and weaknesses; differences in strategy; pricing or resource levels where relevant; gaps left open"),
            S("Trends & Developments", "Look at what is changing", "emerging methods; technology influence; shifts in demand or behavior; risks and uncertainties; what to watch next"),
            S("Data & Evidence", "Ground the analysis", "types of data worth looking up; typical benchmark ranges to verify; strength of evidence; conflicting findings; data gaps"),
            S("Gaps & Opportunities", "Find unmet needs", "underserved areas; weaknesses in common approaches; low-competition angles; skill or knowledge gaps; ways to differentiate"),
            S("Lessons Learned", "Distill the insights", "success factors; common failure causes; counterintuitive findings; practical takeaways; advice for beginners versus experts"),
            S("Source Verification Guide", "Help me confirm the facts", "where to verify claims; reliable source types; red flags for weak sources; claims that need double-checking; how to cite properly"),
            S("Strategic Recommendations", "Turn research into action", "recommended approach; priorities; experiments to run; resources needed; timeline"),
        ],
        extras="comparison tables where useful",
        closing="End with the five most important takeaways, a list of claims I should verify independently, and a summary of recommended next steps.",
    ),
    dict(
        title="Content Creator", role="Content Strategist",
        task="Your task is to create a complete set of high-quality {s} content tailored to my audience and goals.",
        about="the content", intake=["the type of content and platform", "my target audience", "my goal and the action I want readers to take", "tone and brand voice", "key points or keywords to include", "length and deadline"],
        context="the content brief", report="{s} Content Package",
        sections=[
            S("Audience & Angle", "Decide who this is for and why they care", "reader profile; main problem or desire; unique angle; tone that fits; what they should feel and do afterward"),
            S("Content Ideas", "Generate strong topics", "twenty ideas about {s}; mix of educational, practical, and story-driven pieces; difficulty and effort rating; best format for each; priority picks"),
            S("Headlines & Hooks", "Earn attention immediately", "ten headline options; opening lines; curiosity and benefit formulas; examples to avoid; a recommended winner"),
            S("Outline", "Structure the piece", "main sections; flow of ideas; key point per section; transitions; length per section"),
            S("Main Draft", "Write the primary piece from the outline using the plan above."),
            S("Variations", "Adapt to different formats", "short version; long version; social media version; email version; spoken or video script version"),
            S("Calls to Action", "Guide the next step", "primary action; soft alternatives; placement; wording options; ways to track response"),
            S("Visual & Format Suggestions", "Support the words", "images or graphics to create; layout and formatting; examples or diagrams; accessibility notes; platform-specific tips"),
            S("Editing Checklist", "Polish before publishing", "clarity and flow; accuracy checks; tone consistency; grammar and style; trimming filler"),
            S("Distribution Plan", "Get the content seen", "best channels; timing; promotion tactics; communities or partners; follow-up engagement"),
            S("Repurposing Ideas", "Get more from one piece", "formats to convert into; snippets and quotes; series ideas; updates and refreshes; evergreen strategy"),
            S("Performance Tracking", "Learn what works", "metrics to watch; benchmark ranges; review schedule; what to improve based on results; double-down and drop rules"),
        ],
        extras="ready-to-use copy",
        closing="End with the three strongest content pieces to publish first and a summary of how the package supports my goal.",
    ),
]

# --------------------------------------------------------------------------------------
# THE 100 CATEGORIES  x  10 SUBJECTS
# --------------------------------------------------------------------------------------
CATEGORIES = [
    ("Digital Marketing", "SEO; Email Marketing; Paid Advertising; Google Ads; Facebook Ads; Conversion Rate Optimization; Marketing Analytics; Marketing Automation; Local SEO; Influencer Marketing"),
    ("Social Media Growth", "Instagram Growth; TikTok Growth; LinkedIn Growth; X (Twitter) Growth; Pinterest Marketing; Facebook Groups; Community Management; Social Media Calendars; Social Media Analytics; Viral Content"),
    ("Content Writing", "Blog Writing; Long-Form Articles; Ghostwriting; Content Strategy; Content Editing; Case Study Writing; White Paper Writing; Newsletter Writing; Product Descriptions; Content Repurposing"),
    ("Copywriting", "Sales Page Copy; Ad Copywriting; Email Copywriting; Landing Page Copy; Headline Writing; Brand Voice Writing; Video Sales Letters; Direct Response Copy; UX Copywriting; Slogan and Tagline Writing"),
    ("E-commerce", "Shopify Store Setup; Product Research; Cart Abandonment; Product Pages; Inventory Management; Customer Retention; Marketplace Selling; Pricing Strategy; Shipping and Fulfillment; E-commerce SEO"),
    ("Startups & Entrepreneurship", "Idea Validation; Business Model Design; Pitch Decks; Fundraising; MVP Planning; Founder Productivity; Go-to-Market Planning; Startup Pricing; Customer Discovery; Scaling a Startup"),
    ("Business Management", "Team Management; Business Planning; Strategic Planning; Budgeting; KPI Design; Meeting Management; Delegation; Change Management; Business Communication; Performance Reviews"),
    ("Sales", "Cold Outreach; Sales Funnels; Closing Techniques; Sales Scripts; Lead Qualification; CRM Management; Objection Handling; B2B Sales; Sales Forecasting; Account Management"),
    ("Customer Service", "Support Scripts; Complaint Handling; Customer Onboarding; Help Center Design; Live Chat Support; Customer Satisfaction; Escalation Management; Support Team Training; Customer Feedback; Churn Prevention"),
    ("Finance & Investing", "Stock Market Basics; Portfolio Diversification; Index Fund Investing; Financial Statement Analysis; Investment Risk Management; Retirement Investing; Dividend Investing; Mutual Funds; Valuation Basics; Investor Psychology"),
    ("Personal Finance", "Monthly Budgeting; Debt Payoff; Emergency Funds; Saving Strategies; Credit Scores; Tax Planning Basics; Financial Goal Setting; Frugal Living; Money Habits; Side Income Planning"),
    ("Accounting & Bookkeeping", "Bookkeeping Basics; Invoicing; Expense Tracking; Cash Flow Management; Profit and Loss Statements; Payroll Basics; Tax Preparation; Financial Reporting; Accounts Receivable; Small Business Accounting"),
    ("Real Estate", "Property Investing; Rental Property Management; Home Buying; Property Valuation; Real Estate Marketing; Mortgage Planning; House Flipping; Commercial Real Estate; Tenant Screening; Real Estate Negotiation"),
    ("Legal & Contracts", "Contract Review; Freelance Contracts; Business Formation; Intellectual Property Basics; Privacy Policies; Terms of Service; Employment Agreements; NDA Basics; Compliance Basics; Dispute Resolution"),
    ("Human Resources", "Recruiting; Interview Design; Employee Onboarding; Performance Management; Compensation Planning; Employee Engagement; HR Policies; Workplace Conflict Resolution; Talent Retention; Workplace Culture"),
    ("Leadership", "Executive Presence; Team Motivation; Coaching Skills; Leadership Decision Making; Vision Setting; Giving Feedback; Leading Remote Teams; Emotional Intelligence; Crisis Leadership; Leadership Development"),
    ("Project Management", "Agile Planning; Scrum; Project Scheduling; Risk Planning; Stakeholder Management; Resource Planning; Project Budgeting; Kanban; Status Reporting; Project Retrospectives"),
    ("Productivity", "Time Management; Deep Work; Task Prioritization; Habit Building; Goal Setting; Note-Taking Systems; Digital Organization; Focus Management; Morning Routines; Work-Life Balance"),
    ("Career Development", "Career Planning; Career Change; Promotion Strategy; Skill Building; Mentorship; Personal Development Plans; Workplace Networking; Remote Career Growth; Performance Visibility; Professional Reputation"),
    ("Resume & Job Search", "Resume Writing; Cover Letters; ATS Optimization; LinkedIn Profiles; Interview Preparation; Salary Negotiation; Job Applications; Portfolio Building; Networking Outreach; Job Offer Evaluation"),
    ("Education & Teaching", "Lesson Planning; Classroom Management; Curriculum Design; Student Engagement; Assessment Design; Online Teaching; Differentiated Instruction; Teaching Feedback; Course Creation; Tutoring Sessions"),
    ("Study & Exam Prep", "Study Schedules; Memory Techniques; Exam Strategy; Active Recall; Flashcards; Note Taking for Students; Test Anxiety; Essay Exams; Competitive Exams; Revision Planning"),
    ("Language Learning", "English Speaking; Vocabulary Building; Grammar Mastery; Pronunciation; Listening Skills; Writing in a New Language; IELTS Preparation; Spanish Learning; Conversation Practice; Immersion Planning"),
    ("Python Programming", "Python Basics; Python Automation; Web Scraping; Flask Development; Django Development; Python Testing; Data Structures in Python; Python Scripting; Object-Oriented Python; Python Debugging"),
    ("JavaScript & Web Development", "JavaScript Fundamentals; DOM Manipulation; Async JavaScript; React Development; Node.js; TypeScript; Web Performance; Responsive Web Design; Web Accessibility; Browser Debugging"),
    ("Frontend Design", "CSS Layouts; CSS Animation; Design Systems; Tailwind CSS; Component Libraries; Dark Mode Design; Landing Page Building; Frontend Architecture; Cross-Browser Compatibility; Micro-Interactions"),
    ("Backend & APIs", "REST API Design; API Authentication; GraphQL; Microservices; Backend Architecture; API Documentation; Rate Limiting; Caching Strategies; Message Queues; Server Performance"),
    ("Databases & SQL", "SQL Queries; Database Design; Query Optimization; SQLite; PostgreSQL; MongoDB; Database Indexing; Data Modeling; Database Migrations; Backup and Recovery"),
    ("Mobile App Development", "Flutter; React Native; Android Development; iOS Development; App UX; App Store Optimization; Mobile Performance; Push Notifications; App Monetization; Mobile Testing"),
    ("DevOps & Cloud", "Docker; Kubernetes; CI/CD Pipelines; AWS Basics; Cloud Cost Optimization; Infrastructure as Code; Monitoring and Logging; Linux Administration; Git Workflows; Deployment Strategies"),
    ("Cybersecurity", "Web Application Security; Password Security; Network Security; Security Awareness; Incident Response; Threat Modeling; Data Privacy; Secure Coding; Security Audits; Defensive Security Basics"),
    ("Data Analysis", "Excel Analysis; Data Cleaning; Data Visualization; Dashboard Design; Exploratory Analysis; A/B Testing; Business Intelligence; Power BI; Tableau; KPI Reporting"),
    ("Data Science & Machine Learning", "Machine Learning Basics; Feature Engineering; Model Evaluation; Deep Learning; Natural Language Processing; Computer Vision; Time Series Forecasting; Recommendation Systems; MLOps; Data Science Projects"),
    ("AI Prompt Engineering", "ChatGPT Prompts; Prompt Frameworks; Role Prompting; Chain-of-Thought Prompting; Prompt Testing; AI Writing Prompts; AI Coding Prompts; AI Image Prompts; AI Research Prompts; Custom AI Assistants"),
    ("AI Tools & Automation", "Workflow Automation; AI for Business; AI Customer Support; AI Content Workflows; No-Code Automation; AI Agents; AI Data Analysis; AI Meeting Notes; AI Email Management; AI Productivity Systems"),
    ("Excel & Spreadsheets", "Excel Formulas; Pivot Tables; Excel Dashboards; Data Validation; Excel Automation; Google Sheets; Financial Modeling in Excel; Lookup Functions; Conditional Formatting; Spreadsheet Templates"),
    ("UX/UI Design", "User Research; Wireframing; Prototyping; Usability Testing; Information Architecture; Mobile UI Design; Dashboard UX; Onboarding Flows; UX Writing; Figma Workflows"),
    ("Graphic Design", "Logo Design; Typography; Color Theory; Poster Design; Social Media Graphics; Brand Guidelines; Packaging Design; Infographics; Photo Editing; Print Design"),
    ("Video Editing", "Premiere Pro; DaVinci Resolve; Short-Form Editing; Color Grading; Video Storytelling; Sound Design for Video; Motion Graphics; Video Pacing; Subtitles and Captions; Editing Workflow"),
    ("YouTube Growth", "Video Ideas; Titles and Thumbnails; Retention Optimization; YouTube SEO; Channel Branding; YouTube Shorts; Scriptwriting for YouTube; Channel Monetization; Audience Analytics; Content Series"),
    ("Photography", "Portrait Photography; Composition; Lighting; Mobile Photography; Photo Editing Workflow; Product Photography; Landscape Photography; Photography Business; Street Photography; Wedding Photography"),
    ("Music Production", "Beat Making; Mixing; Mastering; Songwriting; Sound Design; Music Theory; Vocal Recording; FL Studio; Ableton Live; Music Marketing"),
    ("Podcasting", "Podcast Launch; Episode Planning; Interview Skills; Audio Editing; Podcast Growth; Podcast Monetization; Guest Booking; Show Notes; Podcast Branding; Recording Setup"),
    ("Creative Writing", "Fiction Writing; Character Development; World Building; Plot Structure; Dialogue Writing; Short Stories; Flash Fiction; Writing Habits; Editing Fiction; Self-Publishing"),
    ("Storytelling & Screenwriting", "Story Structure; Screenplay Formatting; Scriptwriting; Visual Storytelling; Brand Storytelling; Character Arcs; Short Film Writing; Story Pitching; Narrative Hooks; Story Adaptation"),
    ("Public Speaking", "Speech Writing; Stage Presence; Presentation Design; Storytelling in Speeches; Handling Nerves; Q&A Handling; Keynote Talks; Pitch Presentations; Voice Training; Virtual Presenting"),
    ("Communication Skills", "Active Listening; Clear Writing; Difficult Conversations; Email Etiquette; Persuasion; Nonverbal Communication; Assertiveness; Small Talk; Feedback Conversations; Cross-Cultural Communication"),
    ("Negotiation", "Pay Raise Negotiation; Business Negotiation; Contract Negotiation; Conflict Negotiation; Vendor Negotiation; Win-Win Bargaining; Price Negotiation; Negotiation Preparation; Negotiation Psychology; Deal Structuring"),
    ("Psychology & Mindset", "Growth Mindset; Cognitive Biases; Self-Discipline; Confidence Building; Motivation Science; Overcoming Procrastination; Resilience; Habit Psychology; Decision Psychology; Behavior Change"),
    ("Stress & Mindfulness", "Stress Management; Meditation Basics; Breathing Techniques; Burnout Prevention; Mindful Living; Digital Detox; Journaling for Calm; Work Stress; Emotional Regulation; Relaxation Routines"),
    ("Fitness & Workouts", "Strength Training; Home Workouts; Weight Loss Training; Muscle Building; Running; Mobility and Stretching; Beginner Gym Plans; Calisthenics; Workout Consistency; Injury Prevention"),
    ("Nutrition & Meal Planning", "Healthy Meal Prep; Balanced Diet; High-Protein Eating; Budget Meal Planning; Vegetarian Meal Planning; Healthy Snacking; Grocery Planning; Portion Awareness; Family Meal Planning; Nutrition Label Reading"),
    ("Healthy Habits", "Sleep Hygiene; Hydration; Daily Routines; Posture Improvement; Energy Management; Healthy Aging; Habit Tracking; Walking Habits; Screen Time Balance; Wellness Routines"),
    ("Health & Medical Education", "Medical Terminology; Understanding Health Information; Preparing for Doctor Visits; First Aid Basics; Preventive Health; Medicine Safety Basics; Health Research Skills; Medical Study Notes; Anatomy Basics; Public Health Basics"),
    ("Parenting", "Newborn Routines; Toddler Behavior; Positive Discipline; Homework Support; Teen Communication; Screen Time Rules; Family Routines; Parenting Stress; Child Learning Activities; Co-Parenting"),
    ("Relationships", "Couple Communication; Dating Confidence; Friendship Building; Resolving Conflicts; Setting Boundaries; Social Skills; Long-Distance Relationships; Trust Building; Family Relationships; Making New Friends"),
    ("Home & DIY", "Home Organization; Home Repairs; Painting Rooms; Furniture Building; Home Decor; Decluttering; Cleaning Systems; Smart Home Setup; Budget Renovation; Tool Basics"),
    ("Gardening", "Vegetable Gardening; Herb Gardening; Indoor Plants; Composting; Pest Management; Container Gardening; Seasonal Planting; Soil Health; Balcony Gardens; Landscaping Basics"),
    ("Cooking & Recipes", "Home Cooking Basics; Baking; Meal Prep Recipes; Quick Weeknight Dinners; Indian Cooking; Healthy Recipes; Knife Skills; Sauces; Budget Cooking; Recipe Development"),
    ("Travel Planning", "Itinerary Planning; Budget Travel; Solo Travel; Family Trips; Travel Packing; Visa Planning; Road Trips; Trip Photography; Digital Nomad Travel; Travel Safety"),
    ("Fashion & Style", "Wardrobe Building; Personal Style; Capsule Wardrobes; Outfit Planning; Style on a Budget; Fashion Trends; Seasonal Wardrobes; Professional Attire; Accessorizing; Sustainable Fashion"),
    ("Beauty & Skincare", "Skincare Routines; Acne Care Basics; Haircare; Makeup Basics; Sun Protection; Anti-Aging Skincare; Nail Care; Grooming; Product Ingredients; Budget Beauty"),
    ("Personal Branding", "Brand Identity for Individuals; Online Presence; Thought Leadership; Portfolio Websites; Personal Brand Voice; Personal Storytelling; LinkedIn Branding; Reputation Management; Speaking Opportunities; Visibility Strategy"),
    ("Freelancing", "Getting First Clients; Freelance Pricing; Proposals; Client Communication; Client Management; Upwork Success; Fiverr Success; Freelance Portfolio; Scaling Freelance Income; Time Tracking for Freelancers"),
    ("Online Business", "Digital Products; Online Courses; Membership Communities; Coaching Business; Webinar Selling; Business Automation; Customer Acquisition; Subscription Models; Lead Magnets; Online Business Systems"),
    ("Dropshipping & Print on Demand", "Product Selection; Supplier Vetting; Store Branding; Print on Demand Designs; Ad Testing; Customer Support Setup; Order Fulfillment; Profit Margins; Niche Selection; Scaling Dropshipping"),
    ("Affiliate Marketing", "Affiliate Niche Selection; Review Content; Affiliate Funnels; Email Affiliate Marketing; Affiliate SEO; Program Selection; Affiliate Link Strategy; Affiliate YouTube; Affiliate Compliance; Scaling Affiliate Income"),
    ("Blogging & SEO", "Blog Setup; Keyword Research; On-Page SEO; Link Building; Technical SEO; Blog Monetization; Blog Traffic Growth; Topic Clusters; Content Updates; Blog Analytics"),
    ("Email & Newsletters", "Newsletter Launch; Welcome Sequences; Email Segmentation; Subject Lines; List Building; Email Deliverability; Newsletter Monetization; Email Design; Automation Flows; Email Analytics"),
    ("Branding & Identity", "Brand Strategy; Brand Positioning; Naming; Visual Identity; Brand Messaging; Rebranding; Brand Audits; Brand Architecture; Brand Culture; Brand Consistency"),
    ("Product Management", "Product Roadmaps; User Stories; Feature Prioritization; Product Discovery; Product Metrics; Product Launches; Stakeholder Alignment; PRD Writing; Customer Interviews; Product-Market Fit"),
    ("Market Research", "Competitor Analysis; Customer Surveys; Market Sizing; Trend Analysis; Persona Building; Focus Groups; SWOT Analysis; Pricing Research; Industry Reports; Survey Design"),
    ("Supply Chain & Logistics", "Inventory Planning; Demand Forecasting; Warehouse Management; Supplier Management; Logistics Optimization; Procurement; Last-Mile Delivery; Supply Chain Risk; Logistics Cost Reduction; Import and Export Basics"),
    ("Operations & Process Improvement", "Process Mapping; Lean Basics; Six Sigma Basics; SOP Writing; Workflow Design; Quality Control; Capacity Planning; Operational KPIs; Continuous Improvement; Automation Planning"),
    ("Engineering & Manufacturing", "Product Design; CAD Basics; Manufacturing Processes; Quality Assurance; Maintenance Planning; Material Selection; Technical Drawings; Safety Standards; Prototype Development; Production Planning"),
    ("Electronics & Embedded Systems", "Arduino Projects; Raspberry Pi Projects; Circuit Design; Sensors; Microcontrollers; IoT Projects; PCB Design Basics; Embedded C; Electronics Troubleshooting; Home Automation Electronics"),
    ("Game Development", "Unity; Unreal Engine; Game Design; Level Design; Game Mechanics; Game Art; Game Monetization; Indie Game Launch; Godot; Game Testing"),
    ("3D & Animation", "Blender; 3D Modeling; Character Animation; Rigging; Texturing; Motion Design; Rendering; Storyboarding; 2D Animation; Animation Principles"),
    ("Blockchain & Web3", "Blockchain Basics; Smart Contracts; Crypto Security; NFT Concepts; DeFi Basics; Web3 Development; Tokenomics; Wallet Safety; DAO Concepts; Blockchain Careers"),
    ("Math & Statistics", "Algebra; Calculus; Probability; Statistics Basics; Linear Algebra; Problem Solving in Math; Discrete Math; Geometry; Statistical Testing; Math for Data Science"),
    ("Science Learning", "Scientific Method; Science Experiments; Science Communication; Lab Skills; Research Methods; Earth Science; Astronomy; Environmental Science; Science Projects; Reading Scientific Papers"),
    ("Physics", "Mechanics; Electricity and Magnetism; Thermodynamics; Optics; Modern Physics; Physics Problem Solving; Waves; Quantum Basics; Physics Experiments; Physics Exam Prep"),
    ("Chemistry", "Organic Chemistry; Inorganic Chemistry; Chemical Equations; Periodic Table; Stoichiometry; Lab Safety; Chemical Bonding; Chemistry Problem Solving; Physical Chemistry; Chemistry Exam Prep"),
    ("Biology", "Cell Biology; Genetics; Human Anatomy; Ecology; Evolution; Microbiology; Biology Exam Prep; Biochemistry Basics; Plant Biology; Biology Lab Skills"),
    ("History", "World History; Ancient Civilizations; Modern History; History Essays; Historical Research; Indian History; Military History; History Timelines; Primary Source Analysis; History Exam Prep"),
    ("Geography & Cultures", "World Geography; Map Skills; Cultural Studies; Climate and Weather; Human Geography; Cultural Etiquette; Geopolitics Basics; Regional Studies; Urban Geography; Geography Exam Prep"),
    ("Philosophy & Critical Thinking", "Logic; Critical Thinking; Ethics; Argument Analysis; Stoicism; Philosophy Essays; Decision Frameworks; Logical Fallacies; Philosophy of Mind; Thought Experiments"),
    ("Economics", "Microeconomics; Macroeconomics; Behavioral Economics; Supply and Demand; Inflation; Economic Policy Analysis; Game Theory; Development Economics; Economic Data Analysis; Economics Exam Prep"),
    ("Nonprofit & Social Impact", "Nonprofit Startup; Grant Writing; Fundraising Campaigns; Volunteer Management; Impact Measurement; Donor Relations; Community Outreach; Social Enterprise; Nonprofit Marketing; Program Design"),
    ("Event Planning", "Wedding Planning; Corporate Events; Event Budgeting; Venue Selection; Event Marketing; Conference Planning; Birthday Parties; Vendor Coordination; Event Day Management; Virtual Events"),
    ("Hospitality & Restaurants", "Restaurant Startup; Menu Design; Restaurant Marketing; Kitchen Operations; Hotel Management; Guest Experience; Food Cost Control; Staff Training; Cafe Business; Online Food Ordering"),
    ("Agriculture & Farming", "Crop Planning; Organic Farming; Soil Management; Irrigation; Poultry Farming; Dairy Farming; Farm Business Planning; Agri Marketing; Pest Control for Crops; Sustainable Farming"),
    ("Automotive", "Car Buying; Car Maintenance; Vehicle Troubleshooting; Car Detailing; Electric Vehicles; Driving Skills; Car Modifications; Fuel Efficiency; Used Car Inspection; Automotive Business"),
    ("Sports & Coaching", "Cricket Training; Football Coaching; Basketball Skills; Sports Nutrition; Athletic Conditioning; Team Strategy; Youth Coaching; Sports Psychology; Match Analysis; Recovery for Athletes"),
    ("Gaming & Esports", "Game Strategy; Esports Training; Game Streaming; Gaming Content Creation; Team Communication; Gaming Setup; Mobile Gaming; Game Reviews; Competitive Mindset; Gaming Communities"),
    ("Pet Care", "Dog Training; Cat Care; Pet Nutrition; Puppy Care; Pet Grooming; Aquarium Care; Bird Care; Pet Travel; Pet Health Basics; Adopting a Pet"),
    ("Journaling & Self-Reflection", "Daily Journaling; Gratitude Practice; Goal Journaling; Self-Reflection Prompts; Dream Journaling; Reflection Routines; Life Planning; Values Discovery; Weekly Reviews; Bullet Journaling"),
    ("Research & Academic Writing", "Literature Reviews; Thesis Writing; Research Proposals; Citation Styles; Academic Editing; Research Paper Structure; Dissertation Planning; Peer Review; Scholarship Essays; Academic Presentations"),
    ("Technical Writing & Documentation", "Developer Documentation; User Manuals; README Writing; Knowledge Base Articles; SOP Documentation; Release Notes; Technical Tutorials; Style Guides; Documentation Strategy; Documentation Review"),
    ("Interior & Architecture", "Interior Design; Small Space Design; Room Color Schemes; Furniture Layout; Lighting Design; Architectural Basics; Home Planning; Kitchen Design; Sustainable Building; Space Planning"),
]

YEARS = [10, 12, 15, 18, 20]
PROJECTS = ["500", "1,000", "1,500", "2,000", "3,000", "5,000"]


def render(category, subject, fw, idx):
    fmt = lambda t: t.format(s=subject, c=category)
    years = YEARS[idx % len(YEARS)]
    projects = PROJECTS[(idx // 3) % len(PROJECTS)]

    opening = (
        f"Act as a Senior {subject} {fw['role']} with {years}+ years of experience in {category}. "
        f"You have completed over {projects} projects and engagements for clients ranging from beginners and startups "
        f"to established organizations. Your expertise includes {subject} fundamentals, advanced techniques, best "
        f"practices, tools, common pitfalls, and measurable results."
    )
    task = fmt(fw["task"]) + (PRO_NOTE if category in SENSITIVE else "")

    lines = [opening, "", task, ""]
    lines.append(f"Begin by asking detailed questions about {fw['about']}: {join_items([fmt(i) for i in fw['intake']])}.")
    lines.append("")
    lines.append(f"Once you have {fw['context']}, create a thorough {fmt(fw['report'])} that includes:")
    lines.append("")
    for n, (title, intro, items) in enumerate(fw["sections"], 1):
        if items:
            lines.append(f"{n}. **{fmt(title)}** \u2013 {fmt(intro)}: {join_items([fmt(i) for i in items])}.")
        else:
            lines.append(f"{n}. **{fmt(title)}** \u2013 {fmt(intro)}")
        lines.append("")
    lines.append(
        f"Present the report with clear sections, actionable recommendations, and {fw['extras']}. {fw['closing']}"
    )
    return "\n".join(lines).strip()


def generate():
    assert len(CATEGORIES) == 100, f"Expected 100 categories, found {len(CATEGORIES)}"
    assert len(FRAMEWORKS) == 10, "Expected 10 prompt types"
    rows, seen_titles, idx = [], set(), 0
    for category, subjects_str in CATEGORIES:
        subjects = [x.strip() for x in subjects_str.split(";") if x.strip()]
        assert len(subjects) == 10, f"{category}: expected 10 subjects, found {len(subjects)}"
        assert len(set(subjects)) == 10, f"{category}: duplicate subject"
        for subject in subjects:
            for fw in FRAMEWORKS:
                title = f"{subject} {fw['title']}"
                key = (category, title)
                assert key not in seen_titles, f"Duplicate title: {key}"
                seen_titles.add(key)
                text = render(category, subject, fw, idx)
                assert len(text.split()) >= 300, f"{title} too short"
                rows.append((category, title, text))
                idx += 1
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--append", action="store_true", help="keep existing prompts instead of replacing")
    ap.add_argument("--csv", action="store_true", help="also write prompts_10k.csv")
    args = ap.parse_args()

    rows = generate()
    print(f"[OK] Generated {len(rows)} prompts across {len(CATEGORIES)} categories.")

    if args.csv:
        with open(CSV_PATH, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.writer(f)
            w.writerow(["category", "title", "prompt"])
            w.writerows(rows)
        print(f"[OK] Wrote {CSV_PATH}")

    conn = sqlite3.connect(DB_PATH)
    try:
        cur = conn.cursor()
        cur.execute(
            """CREATE TABLE IF NOT EXISTS prompts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                category TEXT NOT NULL, title TEXT NOT NULL, prompt TEXT NOT NULL)"""
        )
        cur.execute("CREATE INDEX IF NOT EXISTS idx_prompts_category ON prompts(category)")
        if not args.append:
            cur.execute("DELETE FROM prompts")
            cur.execute("DELETE FROM sqlite_sequence WHERE name = 'prompts'")
        cur.executemany("INSERT INTO prompts (category, title, prompt) VALUES (?, ?, ?)", rows)
        conn.commit()
        total = cur.execute("SELECT COUNT(*) FROM prompts").fetchone()[0]
        print(f"[OK] aivault.db now holds {total} prompts. Start the site with: python app.py")
    except sqlite3.Error as exc:
        conn.rollback()
        raise SystemExit(f"[ERROR] {exc}")
    finally:
        conn.close()


if __name__ == "__main__":
    main()
